# PCOS Phenotype Navigator

Clinical decision support tool for PCOS diagnosis.
Built for BioHack 2026 — uses the PCOS dataset from Kerala hospitals + endometriosis supplement.

## Quick start

```bash
pip install -r requirements.txt

# 1. Copy your datasets into data/
cp your_pcos.csv data/pcos.csv
cp your_endo.csv data/endo.csv

# 2. Train all three models
python train.py --pcos_path data/pcos.csv --endo_path data/endo.csv

# 3. Launch the app
streamlit run app/app.py
```

## Project structure

```
pcos_navigator/
├── app/
│   └── app.py              # Streamlit UI
├── utils/
│   ├── preprocess.py       # Data loading and cleaning
│   └── rotterdam.py        # Rotterdam criteria logic (2023 guidelines)
├── models/                 # Saved model artefacts (after training)
│   ├── tier1_lr.pkl
│   ├── tier2_rf.pkl
│   ├── diff_xgb.pkl
│   └── metrics.json
├── train.py                # Model training script
└── requirements.txt
```

## Three models

| Model | Features | Algorithm | Use case |
|-------|----------|-----------|----------|
| Tier 1 | Bloods + symptoms (no imaging) | Logistic Regression | Primary care / telehealth |
| Tier 2 | Tier 1 + ultrasound counts | Random Forest | Specialist clinic |
| Differential | Shared PCOS+endo features | XGBoost 3-class | PCOS vs endometriosis vs neither |

## Known dataset limitations (documented in code)

1. `Cycle length(days)` is a coded category (2–12), NOT actual days in this dataset.
   The clinical threshold of >35 days cannot be applied directly.
   `Cycle(R/I)` (2=regular, 4=irregular) is used as the primary Criterion 1 indicator.

2. `LH(mIU/mL)` contains extreme outliers (max: 2018 mIU/mL, likely data entry errors).
   Values are capped at 100 mIU/mL before modelling.

3. Follicle count: the 2023 guideline threshold is ≥20/ovary. Only 3.4% of PCOS-positive
   patients in this dataset meet it (dataset was collected under pre-2023 ≥10 criteria).
   Both thresholds are reported transparently in the Rotterdam mapping output.

4. mFG score not captured — binary `hair growth(Y/N)` is used as a proxy.
   The app accepts mFG input directly when available.

5. Ovarian volume not in dataset — the alternative 2023 criterion (>10 cm³) cannot
   be assessed. Flagged in the UI.

## Judging criteria alignment

- **Clinical validity (30%)**: Rotterdam criteria mapped explicitly with correct 2023 thresholds;
  dataset limitations documented; phenotype A–D classification included.
- **Diagnostic accuracy (20%)**: Differential classifier handles PCOS vs endometriosis;
  tiered design accounts for patient heterogeneity and resource availability.
- **Feasibility (20%)**: Tier 1 requires only blood tests — suitable for primary care/telehealth;
  Tier 2 adds ultrasound for specialist settings.
- **Innovation (12%)**: Differential diagnosis angle + transparent guideline versioning.
- **Methodology (10%)**: Stratified 5-fold CV; class_weight='balanced' for imbalanced classes;
  separate imputation pipelines per tier to prevent leakage.
