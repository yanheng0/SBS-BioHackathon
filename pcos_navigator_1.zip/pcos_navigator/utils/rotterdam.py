"""
rotterdam.py
Implements the Rotterdam criteria for PCOS diagnosis with correct 2023 thresholds.

Important dataset caveats documented here:
  - Cycle length(days): encoded as a category (2-12), NOT actual days.
    Cannot apply the >35 day threshold directly. Use Cycle(R/I) instead.
  - LH(mIU/mL): severe outliers present; use with caution after capping.
  - Follicle count: 2023 guidelines require ≥20/ovary, but only 3.4% of
    PCOS patients in this dataset meet that threshold. Dataset was collected
    under older (≥10) criteria. Both thresholds are reported transparently.
  - mFG score: not captured in dataset; hair growth(Y/N) is a binary proxy only.
  - Ovarian volume: not captured; follicle count is the only ultrasound proxy.
"""

from dataclasses import dataclass
from typing import Optional


# ── Threshold constants ──────────────────────────────────────────────────────

# Criterion 1: Oligo/anovulation
CYCLE_IRREGULAR_CODE = 4          # Cycle(R/I) == 4 means irregular
CYCLE_LENGTH_THRESHOLD_DAYS = 35  # >35 days = oligomenorrhea
                                  # NOTE: Cycle length(days) in dataset is
                                  # a coded category, not actual days.
                                  # Use Cycle(R/I) as primary indicator.

# Criterion 2: Hyperandrogenism (biochemical)
LH_ELEVATED_THRESHOLD = 10        # mIU/mL — elevated LH
FSH_LH_INVERTED_THRESHOLD = 1.0   # FSH/LH < 1 = LH dominance (PCOS pattern)
AMH_ELEVATED_THRESHOLD = 3.5      # ng/mL — elevated ovarian reserve marker

# Criterion 2: Hyperandrogenism (clinical)
# mFG score thresholds by ethnicity (not available in dataset — binary proxy used)
MFG_THRESHOLD_CAUCASIAN = 6
MFG_THRESHOLD_EAST_ASIAN = 4
MFG_THRESHOLD_DEFAULT = 4         # Conservative default per 2023 guidelines

# Criterion 3: Polycystic ovarian morphology
FOLLICLE_THRESHOLD_2023 = 20      # 2023 international guidelines
FOLLICLE_THRESHOLD_2018 = 10      # Pre-2023 threshold (what dataset was collected under)
FOLLICLE_THRESHOLD_VOLUME_CM3 = 10  # Alternative: ovarian volume > 10 cm³ (not in dataset)


@dataclass
class CriterionResult:
    name: str
    met: bool
    partial: bool           # True if borderline / proxy used
    evidence: list          # List of strings explaining what was found
    caveat: Optional[str]   # Dataset limitation note if applicable
    threshold_used: str     # Which guideline threshold was applied


@dataclass
class RotterdamResult:
    criterion1: CriterionResult
    criterion2: CriterionResult
    criterion3: CriterionResult
    criteria_met: int       # Count of fully met criteria
    diagnosis_supported: bool   # True if ≥2 criteria met
    guideline_version: str
    dataset_caveats: list


def assess_criterion1(row: dict) -> CriterionResult:
    """
    Criterion 1: Oligo- or anovulation.
    Primary indicator: Cycle(R/I) == 4 (irregular).
    Secondary note: Cycle length(days) cannot be used directly — it is
    a coded category in this dataset, not actual cycle duration in days.
    """
    evidence = []
    caveats = []

    cycle_irregular = row.get('Cycle(R/I)') == CYCLE_IRREGULAR_CODE
    cycle_length_raw = row.get('Cycle length(days)')

    if cycle_irregular:
        evidence.append("Menstrual cycle coded as irregular (Cycle R/I = 4)")
    else:
        evidence.append("Menstrual cycle coded as regular (Cycle R/I = 2)")

    if cycle_length_raw is not None:
        evidence.append(
            f"Cycle length field value: {cycle_length_raw} "
            f"(note: this is a coded category in the dataset, not days)"
        )
        caveats.append(
            "Cycle length(days) in this dataset encodes a category (2–12), "
            "not actual days. The clinical threshold of >35 days or <8 periods/year "
            "cannot be applied directly. Cycle(R/I) is used as the primary indicator."
        )

    met = cycle_irregular
    partial = not cycle_irregular and cycle_length_raw is not None and cycle_length_raw >= 6

    return CriterionResult(
        name="Oligo/anovulation",
        met=met,
        partial=partial,
        evidence=evidence,
        caveat=" ".join(caveats) if caveats else None,
        threshold_used="Cycle(R/I) == 4 (irregular coding); "
                       "clinical standard >35 days not directly measurable in dataset",
    )


def assess_criterion2(row: dict, mfg_score: Optional[int] = None,
                       ethnicity: str = 'default') -> CriterionResult:
    """
    Criterion 2: Clinical and/or biochemical hyperandrogenism.
    Biochemical: elevated LH, inverted FSH/LH ratio, elevated AMH
    Clinical: mFG score (not in dataset — binary hair growth proxy used)
    """
    evidence = []
    caveats = []
    biochem_flags = []
    clinical_flags = []

    # Biochemical assessment
    lh = row.get('LH(mIU/mL)')
    fsh_lh = row.get('FSH/LH')
    amh = row.get('AMH(ng/mL)')

    if lh is not None:
        if lh > LH_ELEVATED_THRESHOLD:
            biochem_flags.append(f"LH elevated: {lh:.1f} mIU/mL (threshold: >{LH_ELEVATED_THRESHOLD})")
        else:
            evidence.append(f"LH: {lh:.1f} mIU/mL (not elevated; threshold >{LH_ELEVATED_THRESHOLD})")

    if fsh_lh is not None:
        if fsh_lh < FSH_LH_INVERTED_THRESHOLD:
            biochem_flags.append(
                f"FSH/LH ratio inverted: {fsh_lh:.2f} (threshold: <{FSH_LH_INVERTED_THRESHOLD} "
                f"indicates LH dominance)"
            )
        else:
            evidence.append(f"FSH/LH ratio: {fsh_lh:.2f} (normal; LH not dominant)")

    if amh is not None:
        if amh > AMH_ELEVATED_THRESHOLD:
            biochem_flags.append(
                f"AMH elevated: {amh:.1f} ng/mL (threshold >{AMH_ELEVATED_THRESHOLD}; "
                f"indicates enlarged ovarian reserve)"
            )
        else:
            evidence.append(f"AMH: {amh:.1f} ng/mL (not markedly elevated)")

    # Clinical hyperandrogenism
    if mfg_score is not None:
        mfg_thresh = {
            'east_asian': MFG_THRESHOLD_EAST_ASIAN,
            'caucasian': MFG_THRESHOLD_CAUCASIAN,
        }.get(ethnicity, MFG_THRESHOLD_DEFAULT)
        if mfg_score >= mfg_thresh:
            clinical_flags.append(
                f"mFG score {mfg_score} ≥ {mfg_thresh} (ethnicity-adjusted threshold; "
                f"clinical hirsutism confirmed)"
            )
        else:
            evidence.append(
                f"mFG score {mfg_score} < {mfg_thresh} (below hirsutism threshold for "
                f"{ethnicity} ethnicity)"
            )
    else:
        # Fall back to binary proxy
        hair_growth = row.get('hair growth(Y/N)', 0)
        skin_dark = row.get('Skin darkening (Y/N)', 0)
        if hair_growth:
            clinical_flags.append("Hirsutism reported (binary proxy — mFG score not captured in dataset)")
        if skin_dark:
            clinical_flags.append("Acanthosis nigricans present (hyperinsulinaemia marker)")
        caveats.append(
            "mFG score not available in dataset. hair growth(Y/N) is a binary proxy only. "
            "A real deployment should collect mFG score with ethnicity-adjusted thresholds "
            f"(≥{MFG_THRESHOLD_EAST_ASIAN} East Asian, ≥{MFG_THRESHOLD_CAUCASIAN} Caucasian)."
        )

    all_flags = biochem_flags + clinical_flags
    evidence = all_flags + evidence

    met = len(all_flags) >= 1
    partial = not met and len(evidence) > 0

    return CriterionResult(
        name="Clinical/biochemical hyperandrogenism",
        met=met,
        partial=partial,
        evidence=evidence,
        caveat=" ".join(caveats) if caveats else None,
        threshold_used=(
            f"LH >{LH_ELEVATED_THRESHOLD} mIU/mL OR FSH/LH <{FSH_LH_INVERTED_THRESHOLD} "
            f"OR AMH >{AMH_ELEVATED_THRESHOLD} ng/mL; "
            f"clinical: mFG ≥{MFG_THRESHOLD_DEFAULT} (default) or binary hair growth proxy"
        ),
    )


def assess_criterion3(row: dict, apply_2023_guidelines: bool = True) -> CriterionResult:
    """
    Criterion 3: Polycystic ovarian morphology on ultrasound.
    2023 guideline: ≥20 follicles per ovary OR ovarian volume >10 cm³.
    Pre-2023: ≥10 follicles per ovary.

    IMPORTANT: Only 3.4% of PCOS-positive patients in this dataset meet the
    2023 threshold (≥20). The dataset was collected under older criteria.
    Both assessments are reported transparently.
    """
    evidence = []
    caveats = []

    fol_r = row.get('Follicle No. (R)')
    fol_l = row.get('Follicle No. (L)')

    threshold = FOLLICLE_THRESHOLD_2023 if apply_2023_guidelines else FOLLICLE_THRESHOLD_2018
    guideline = "2023" if apply_2023_guidelines else "pre-2023"

    met_2023 = False
    met_2018 = False

    if fol_r is not None:
        evidence.append(f"Right ovary: {int(fol_r)} follicles")
        met_2023 = met_2023 or fol_r >= FOLLICLE_THRESHOLD_2023
        met_2018 = met_2018 or fol_r >= FOLLICLE_THRESHOLD_2018

    if fol_l is not None:
        evidence.append(f"Left ovary: {int(fol_l)} follicles")
        met_2023 = met_2023 or fol_l >= FOLLICLE_THRESHOLD_2023
        met_2018 = met_2018 or fol_l >= FOLLICLE_THRESHOLD_2018

    if fol_r is None and fol_l is None:
        evidence.append("Ultrasound data not available")
        caveats.append("Criterion 3 cannot be assessed without ultrasound.")
        return CriterionResult(
            name="Polycystic ovarian morphology",
            met=False, partial=False,
            evidence=evidence, caveat=" ".join(caveats),
            threshold_used=f"≥{threshold} follicles/ovary ({guideline} guidelines)",
        )

    # Log both threshold results for transparency
    if apply_2023_guidelines and not met_2023 and met_2018:
        evidence.append(
            f"Meets pre-2023 threshold (≥{FOLLICLE_THRESHOLD_2018}) but NOT "
            f"2023 threshold (≥{FOLLICLE_THRESHOLD_2023}). "
            f"This patient would have been flagged under older diagnostic criteria."
        )
        caveats.append(
            f"Dataset collected under pre-2023 criteria. Only 3.4% of PCOS patients in "
            f"this dataset meet the updated ≥{FOLLICLE_THRESHOLD_2023} threshold. "
            f"Ovarian volume (>10 cm³) is the recommended alternative confirmatory measure "
            f"but is not captured in this dataset."
        )

    met = met_2023 if apply_2023_guidelines else met_2018
    partial = apply_2023_guidelines and not met_2023 and met_2018

    return CriterionResult(
        name="Polycystic ovarian morphology",
        met=met,
        partial=partial,
        evidence=evidence,
        caveat=" ".join(caveats) if caveats else None,
        threshold_used=(
            f"≥{FOLLICLE_THRESHOLD_2023} follicles/ovary (2023 ESHRE/ASRM guidelines) "
            f"OR ovarian volume >10 cm³ (not in dataset). "
            f"Pre-2023 threshold ≥{FOLLICLE_THRESHOLD_2018} also reported."
        ),
    )


def apply_rotterdam(row: dict,
                    mfg_score: Optional[int] = None,
                    ethnicity: str = 'default',
                    apply_2023_guidelines: bool = True) -> RotterdamResult:
    """
    Full Rotterdam criteria assessment for a single patient.
    Returns structured result with evidence, caveats, and diagnosis support flag.
    """
    c1 = assess_criterion1(row)
    c2 = assess_criterion2(row, mfg_score=mfg_score, ethnicity=ethnicity)
    c3 = assess_criterion3(row, apply_2023_guidelines=apply_2023_guidelines)

    criteria_met = sum([c1.met, c2.met, c3.met])
    diagnosis_supported = criteria_met >= 2

    dataset_caveats = [c.caveat for c in [c1, c2, c3] if c.caveat]

    return RotterdamResult(
        criterion1=c1,
        criterion2=c2,
        criterion3=c3,
        criteria_met=criteria_met,
        diagnosis_supported=diagnosis_supported,
        guideline_version="2023 ESHRE/ASRM" if apply_2023_guidelines else "2018 Rotterdam",
        dataset_caveats=dataset_caveats,
    )
