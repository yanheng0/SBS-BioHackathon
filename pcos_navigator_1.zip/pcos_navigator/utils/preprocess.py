"""
preprocess.py
Cleans and prepares the PCOS dataset and the endometriosis supplement.
Handles known data quality issues discovered during EDA:
  - Cycle length(days) is a coded category, NOT actual days
  - LH(mIU/mL) has extreme outliers (max 2018) requiring capping
  - AMH and II beta-HCG are stored as strings in the raw CSV
"""

import pandas as pd
import numpy as np
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler
import joblib
import os

# ── Feature sets ────────────────────────────────────────────────────────────
# Tier 1: no imaging required (primary care / telehealth safe)
TIER1_FEATURES = [
    'Age (yrs)',
    'BMI',
    'LH(mIU/mL)',
    'FSH(mIU/mL)',
    'FSH/LH',
    'AMH(ng/mL)',
    'Cycle(R/I)',          # 2=regular, 4=irregular
    'hair growth(Y/N)',
    'Skin darkening (Y/N)',
    'Weight gain(Y/N)',
    'Pimples(Y/N)',
    'Hair loss(Y/N)',
    'Fast food (Y/N)',
    'Reg.Exercise(Y/N)',
]

# Tier 2: adds ultrasound measurements
TIER2_FEATURES = TIER1_FEATURES + [
    'Follicle No. (L)',
    'Follicle No. (R)',
    'Avg. F size (L) (mm)',
    'Avg. F size (R) (mm)',
    'Endometrium (mm)',
]

TARGET = 'PCOS (Y/N)'


def load_pcos(path: str) -> pd.DataFrame:
    """Load and clean the main PCOS dataset."""
    df = pd.read_csv(path)

    # Fix columns stored as strings
    df['AMH(ng/mL)'] = pd.to_numeric(df['AMH(ng/mL)'], errors='coerce')
    df['II    beta-HCG(mIU/mL)'] = pd.to_numeric(
        df['II    beta-HCG(mIU/mL)'], errors='coerce'
    )

    # Rename for consistency (leading space in original)
    df.rename(columns={' Age (yrs)': 'Age (yrs)'}, inplace=True)

    # Cap LH outliers — values above 100 are likely data entry errors
    # Clinical note: normal LH range is 1-20 mIU/mL; PCOS mean in this dataset is 14.4
    df['LH(mIU/mL)'] = df['LH(mIU/mL)'].clip(upper=100)

    # Drop rows without a PCOS label
    df = df.dropna(subset=[TARGET])
    df[TARGET] = df[TARGET].astype(int)

    return df


def load_endometriosis(path: str) -> pd.DataFrame:
    """
    Load endometriosis supplement and map to shared feature space.
    Original columns: Age, Menstrual_Irregularity, Chronic_Pain_Level,
                      Hormone_Level_Abnormality, Infertility, BMI, Diagnosis
    """
    df = pd.read_csv(path)

    # Map to PCOS feature names where possible
    mapping = {
        'Age': 'Age (yrs)',
        'BMI': 'BMI',
        'Menstrual_Irregularity': 'Cycle(R/I)',   # will recode below
        'Hormone_Level_Abnormality': 'hormone_abnormal',
        'Chronic_Pain_Level': 'chronic_pain',
        'Infertility': 'Infertility',
        'Diagnosis': 'endo_label',
    }
    df = df.rename(columns=mapping)

    # Recode cycle: endo uses 0/1, PCOS uses 2=regular/4=irregular
    df['Cycle(R/I)'] = df['Cycle(R/I)'].map({0: 2, 1: 4})

    # Fill features unavailable in endo dataset with NaN
    # (imputer will handle these)
    for feat in TIER1_FEATURES:
        if feat not in df.columns:
            df[feat] = np.nan

    return df


def build_differential_dataset(pcos_df: pd.DataFrame,
                                endo_df: pd.DataFrame) -> tuple:
    """
    Merge both datasets for the 3-class differential classifier.
    Classes: 0 = neither, 1 = PCOS, 2 = endometriosis
    Uses only shared/inferable features to avoid data leakage.
    """
    shared_features = [
        'Age (yrs)', 'BMI', 'Cycle(R/I)',
        'hair growth(Y/N)', 'Weight gain(Y/N)',
        'FSH/LH', 'AMH(ng/mL)',
    ]

    pcos_sub = pcos_df[shared_features + [TARGET]].copy()
    pcos_sub['diff_label'] = pcos_sub[TARGET].map({1: 1, 0: 0})

    endo_sub = endo_df[shared_features + ['endo_label']].copy()
    endo_sub['diff_label'] = endo_sub['endo_label'].map({1: 2, 0: 0})

    merged = pd.concat([
        pcos_sub[shared_features + ['diff_label']],
        endo_sub[shared_features + ['diff_label']],
    ], ignore_index=True)

    X = merged[shared_features]
    y = merged['diff_label']
    return X, y, shared_features


def get_feature_matrix(df: pd.DataFrame, tier: int = 1) -> pd.DataFrame:
    """Return feature matrix for the given tier."""
    features = TIER1_FEATURES if tier == 1 else TIER2_FEATURES
    available = [f for f in features if f in df.columns]
    return df[available]


class PCOSPreprocessor:
    """
    Fits imputer + scaler on training data and transforms consistently.
    Saves artefacts to disk so the Streamlit app can load them without retraining.
    """

    def __init__(self):
        self.imputer = SimpleImputer(strategy='median')
        self.scaler = StandardScaler()
        self.feature_names = None

    def fit_transform(self, X: pd.DataFrame) -> np.ndarray:
        self.feature_names = list(X.columns)
        X_imp = self.imputer.fit_transform(X)
        X_scaled = self.scaler.fit_transform(X_imp)
        return X_scaled

    def transform(self, X: pd.DataFrame) -> np.ndarray:
        # Align columns to training order; fill missing with NaN
        X_aligned = X.reindex(columns=self.feature_names)
        X_imp = self.imputer.transform(X_aligned)
        X_scaled = self.scaler.transform(X_imp)
        return X_scaled

    def save(self, dir_path: str):
        joblib.dump(self.imputer, os.path.join(dir_path, 'imputer.pkl'))
        joblib.dump(self.scaler, os.path.join(dir_path, 'scaler.pkl'))
        joblib.dump(self.feature_names, os.path.join(dir_path, 'feature_names.pkl'))

    def load(self, dir_path: str):
        self.imputer = joblib.load(os.path.join(dir_path, 'imputer.pkl'))
        self.scaler = joblib.load(os.path.join(dir_path, 'scaler.pkl'))
        self.feature_names = joblib.load(os.path.join(dir_path, 'feature_names.pkl'))
        return self
