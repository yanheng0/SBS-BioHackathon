"""
train.py
Trains all three models and saves artefacts to /models:
  1. tier1_lr   — Logistic Regression (no imaging features)
  2. tier2_rf   — Random Forest (full feature set including ultrasound)
  3. diff_xgb   — XGBoost 3-class differential (PCOS / endo / neither)

Run: python train.py --pcos_path data/pcos.csv --endo_path data/endo.csv
"""

import argparse
import os
import json
import numpy as np
import pandas as pd
import joblib
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import StratifiedKFold, cross_validate
from sklearn.metrics import roc_auc_score, classification_report
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler
from xgboost import XGBClassifier

import sys
sys.path.append(os.path.dirname(os.path.dirname(__file__)))
from utils.preprocess import (
    load_pcos, load_endometriosis, build_differential_dataset,
    get_feature_matrix, TIER1_FEATURES, TIER2_FEATURES, TARGET
)


def build_pipeline_lr():
    """Logistic Regression pipeline with imputation + scaling."""
    return Pipeline([
        ('imputer', SimpleImputer(strategy='median')),
        ('scaler', StandardScaler()),
        ('model', LogisticRegression(
            class_weight='balanced',  # handles 177/364 imbalance
            max_iter=2000,
            C=0.5,                    # light regularisation
            random_state=42,
        )),
    ])


def build_pipeline_rf():
    """Random Forest pipeline — scaling not needed but imputation is."""
    return Pipeline([
        ('imputer', SimpleImputer(strategy='median')),
        ('model', RandomForestClassifier(
            n_estimators=500,
            class_weight='balanced',
            max_depth=8,
            min_samples_leaf=5,
            random_state=42,
            n_jobs=-1,
        )),
    ])


def build_pipeline_xgb(n_classes: int = 3):
    """XGBoost pipeline for multi-class differential."""
    return Pipeline([
        ('imputer', SimpleImputer(strategy='median')),
        ('model', XGBClassifier(
            objective='multi:softprob',
            num_class=n_classes,
            n_estimators=300,
            max_depth=5,
            learning_rate=0.05,
            subsample=0.8,
            colsample_bytree=0.8,
            eval_metric='mlogloss',
            use_label_encoder=False,
            random_state=42,
        )),
    ])


def evaluate_binary(pipeline, X, y, label: str):
    """5-fold stratified cross-validation for binary classifiers."""
    cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)
    results = cross_validate(
        pipeline, X, y, cv=cv,
        scoring=['roc_auc', 'recall', 'precision', 'f1'],
        return_train_score=False,
    )
    print(f"\n── {label} ──")
    for metric, vals in results.items():
        if metric.startswith('test_'):
            name = metric.replace('test_', '')
            print(f"  {name:12s}: {np.mean(vals):.3f} ± {np.std(vals):.3f}")
    return {k.replace('test_',''): float(np.mean(v))
            for k, v in results.items() if k.startswith('test_')}


def train_tier1(df: pd.DataFrame, models_dir: str) -> dict:
    """Train and save Tier 1 logistic regression."""
    features = [f for f in TIER1_FEATURES if f in df.columns]
    X = df[features]
    y = df[TARGET]

    pipeline = build_pipeline_lr()
    metrics = evaluate_binary(pipeline, X, y, "Tier 1 — Logistic Regression")

    # Refit on full dataset
    pipeline.fit(X, y)
    joblib.dump(pipeline, os.path.join(models_dir, 'tier1_lr.pkl'))
    joblib.dump(features, os.path.join(models_dir, 'tier1_features.pkl'))

    print(f"  Saved tier1_lr.pkl  (features: {len(features)})")
    return metrics


def train_tier2(df: pd.DataFrame, models_dir: str) -> dict:
    """Train and save Tier 2 random forest."""
    features = [f for f in TIER2_FEATURES if f in df.columns]
    X = df[features]
    y = df[TARGET]

    pipeline = build_pipeline_rf()
    metrics = evaluate_binary(pipeline, X, y, "Tier 2 — Random Forest")

    pipeline.fit(X, y)
    joblib.dump(pipeline, os.path.join(models_dir, 'tier2_rf.pkl'))
    joblib.dump(features, os.path.join(models_dir, 'tier2_features.pkl'))

    print(f"  Saved tier2_rf.pkl  (features: {len(features)})")
    return metrics


def train_differential(pcos_df: pd.DataFrame, endo_df: pd.DataFrame,
                        models_dir: str) -> dict:
    """Train and save 3-class differential classifier."""
    X, y, features = build_differential_dataset(pcos_df, endo_df)

    pipeline = build_pipeline_xgb(n_classes=3)

    # Multi-class CV
    cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)
    results = cross_validate(
        pipeline, X, y, cv=cv,
        scoring=['f1_macro', 'accuracy'],
        return_train_score=False,
    )
    print("\n── Differential classifier — XGBoost 3-class ──")
    for metric, vals in results.items():
        if metric.startswith('test_'):
            name = metric.replace('test_', '')
            print(f"  {name:12s}: {np.mean(vals):.3f} ± {np.std(vals):.3f}")

    pipeline.fit(X, y)
    joblib.dump(pipeline, os.path.join(models_dir, 'diff_xgb.pkl'))
    joblib.dump(features, os.path.join(models_dir, 'diff_features.pkl'))

    print(f"  Saved diff_xgb.pkl  (features: {len(features)})")
    metrics = {k.replace('test_', ''): float(np.mean(v))
               for k, v in results.items() if k.startswith('test_')}
    return metrics


def save_metrics(all_metrics: dict, models_dir: str):
    path = os.path.join(models_dir, 'metrics.json')
    with open(path, 'w') as f:
        json.dump(all_metrics, f, indent=2)
    print(f"\nMetrics saved to {path}")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--pcos_path', required=True)
    parser.add_argument('--endo_path', required=True)
    parser.add_argument('--models_dir', default='models')
    args = parser.parse_args()

    os.makedirs(args.models_dir, exist_ok=True)

    print("Loading datasets...")
    pcos_df = load_pcos(args.pcos_path)
    endo_df = load_endometriosis(args.endo_path)
    print(f"  PCOS: {len(pcos_df)} patients "
          f"({pcos_df[TARGET].sum()} PCOS, {(pcos_df[TARGET]==0).sum()} controls)")
    print(f"  Endo: {len(endo_df)} patients")

    all_metrics = {}
    all_metrics['tier1'] = train_tier1(pcos_df, args.models_dir)
    all_metrics['tier2'] = train_tier2(pcos_df, args.models_dir)
    all_metrics['differential'] = train_differential(
        pcos_df, endo_df, args.models_dir
    )

    save_metrics(all_metrics, args.models_dir)
    print("\nTraining complete.")


if __name__ == '__main__':
    main()
